var searchData=
[
  ['salespitch',['salespitch',['../classsalespitch.html',1,'']]],
  ['save',['save',['../classRecord.html#a166d102bda3d2cee29e9cbb79aea5a55',1,'Record']]],
  ['sethasrecieved',['setHasRecieved',['../classRecord.html#a0aec1fe9e064f4d96bb10cd80864f43a',1,'Record']]],
  ['setinterest',['setInterest',['../classRecord.html#a22a050dea7b11a40ab40d0eb2fbd9802',1,'Record']]],
  ['setuserindex',['setUserIndex',['../classRecord.html#a097c93d1baeba923690d00f916df8f9b',1,'Record']]]
];
