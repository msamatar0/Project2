var searchData=
[
  ['record',['Record',['../classRecord.html#ae8ee53ffec6ff4dac9911517d47e86a5',1,'Record::Record()'],['../classRecord.html#a5754dc31dc8f2c45a3cf551bab0e8e26',1,'Record::Record(QVector&lt; QString &gt;, QVector&lt; QString &gt;, QVector&lt; QString &gt;, QVector&lt; QString &gt;, QVector&lt; QString &gt;, QVector&lt; bool &gt;, QVector&lt; bool &gt;, QString)'],['../classRecord.html#ad9a0b93dc14adf6ffc8ba87379d22a46',1,'Record::Record(const Record &amp;obj)']]],
  ['remove',['remove',['../classRecord.html#a05bd8293472b1d21f8a079ebd90ae1c0',1,'Record']]]
];
