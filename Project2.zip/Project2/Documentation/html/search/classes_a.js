var searchData=
[
  ['salespitch',['salespitch',['../classsalespitch.html',1,'']]]
];
