var searchData=
[
  ['deletecustomer',['deleteCustomer',['../classdeleteCustomer.html',1,'']]]
];
