var searchData=
[
  ['deletecustomer',['deleteCustomer',['../classaddCustomer.html#aaa4e310060fd815ef0e2caef00c2e39d',1,'addCustomer::deleteCustomer()'],['../classdeleteCustomer.html#a6ad98add391497169b04f02f308fee72',1,'deleteCustomer::deleteCustomer()']]]
];
