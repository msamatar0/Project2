var searchData=
[
  ['operator_3d',['operator=',['../classRecord.html#ad5bfe151ddac7473e6e33b0c1228f38c',1,'Record']]]
];
