var searchData=
[
  ['errorwindow',['errorWindow',['../classerrorWindow.html',1,'errorWindow'],['../classerrorWindow.html#af110b20ece33c61b0c71c1aad030a0a4',1,'errorWindow::errorWindow(QWidget *parent=0)'],['../classerrorWindow.html#a0cd7262b61034d83d525cc0a3d33b50f',1,'errorWindow::errorWindow(QWidget *parent, QString)']]]
];
