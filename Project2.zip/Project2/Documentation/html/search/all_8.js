var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classRecord.html#a26efee1aece176a29a41193e947d389a',1,'Record']]],
  ['operator_3d',['operator=',['../classRecord.html#ad5bfe151ddac7473e6e33b0c1228f38c',1,'Record']]],
  ['orderform',['orderform',['../classorderform.html',1,'']]]
];
