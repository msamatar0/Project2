var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classRecord.html#a26efee1aece176a29a41193e947d389a',1,'Record']]]
];
