var searchData=
[
  ['getaddress',['getAddress',['../classRecord.html#a7d029c4ada2af9240930c43face661c1',1,'Record']]],
  ['getaddresslist1',['getAddressList1',['../classRecord.html#a7e8ab4ebf76b059c990f67bb2cb56fc6',1,'Record']]],
  ['getaddresslist2',['getAddressList2',['../classRecord.html#a1ca2a18f5b4826e5a6ffdf8c218eef03',1,'Record']]],
  ['gethasrecieved',['getHasRecieved',['../classRecord.html#a27e0177123b1433bf434ba88decb1ff9',1,'Record']]],
  ['getinterestlist',['getInterestList',['../classRecord.html#a4b1f4740ec8f3b5241a41b5027eb7804',1,'Record']]],
  ['getkeylist',['getKeyList',['../classRecord.html#ac903768fca422bbefad7235df073db86',1,'Record']]],
  ['getnamelist',['getNameList',['../classRecord.html#ad8b2132870a38134c838827ac1510196',1,'Record']]],
  ['getrecievedlist',['getRecievedList',['../classRecord.html#a8bbfb2bd85380e51dd941711579a7070',1,'Record']]],
  ['getstatuslist',['getStatusList',['../classRecord.html#a64376c563c42d61183177f602f549216',1,'Record']]],
  ['gettestimonial',['getTestimonial',['../classRecord.html#af6066736aa251b6446d2a241510e8bcb',1,'Record']]],
  ['getuserindex',['getUserIndex',['../classRecord.html#aa76f44f4f4f4d40df641047eddfbf855',1,'Record']]]
];
