#include "person.h"

QString person::getName() {
    return this->name;
}
