#include "admin.h"


void admin::print() {

    //code

}

bool admin::validate(QString str) {
    return (password == str);
}
